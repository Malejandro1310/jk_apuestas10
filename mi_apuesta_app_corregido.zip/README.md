# App de Apuestas Deportivas

Esta aplicación fue creada con Streamlit. Permite registrar usuarios, enviar notificaciones por correo, y gestionar cuentas desde un panel administrativo.

## Ejecutar localmente

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy online

1. Sube estos archivos a un repositorio en GitHub.
2. Ve a https://streamlit.io/cloud
3. Conéctalo a tu cuenta GitHub y elige este repositorio.
4. Asegúrate de que `app.py` es el archivo principal.
