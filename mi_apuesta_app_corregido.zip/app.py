import re
import csv
import os
import streamlit as st
import pandas as pd

# Función para enviar el correo (previamente definida)
def enviar_email_retiro(servidor_smtp, puerto, remitente, clave, destinatario, partido, fecha_retiro):
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    mensaje = MIMEMultipart()
    mensaje["From"] = remitente
    mensaje["To"] = destinatario
    mensaje["Subject"] = "💸 Retiro registrado en una apuesta"

    cuerpo = f"""    Se ha registrado un retiro anticipado en el partido:

    🏟 Partido: {partido}
    📅 Fecha de retiro: {fecha_retiro}

    Revisa los detalles en la app.
    """
    mensaje.attach(MIMEText(cuerpo, "plain"))

    try:
        with smtplib.SMTP(servidor_smtp, puerto) as servidor:
            servidor.starttls()
            servidor.login(remitente, clave)
            servidor.sendmail(remitente, destinatario, mensaje.as_string())
            print("✅ Correo enviado con éxito")
    except Exception as e:
        print("❌ Error al enviar correo:", e)

# Validación de correo

def es_correo_valido(correo):
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", correo))

# Lista de correos administradores permitidos
correos_admin = ["mikkyy_13@hotmail.com"]

# Archivo de usuarios
usuarios_file = "usuarios.csv"

# Función para iniciar sesión

def iniciar_sesion(usuario_input, clave_input):
    if not os.path.exists(usuarios_file):
        return None
    with open(usuarios_file, mode='r', encoding='utf-8') as archivo:
        reader = csv.DictReader(archivo)
        for fila in reader:
            if fila["Usuario"] == usuario_input and fila["Clave"] == clave_input:
                return fila  # Devuelve datos del usuario
    return None

# Streamlit UI para login
st.title("🔐 Iniciar sesión")

with st.form("login_form"):
    usuario_login = st.text_input("Usuario")
    clave_login = st.text_input("Contraseña", type="password")
    enviar = st.form_submit_button("Ingresar")

if enviar:
    sesion = iniciar_sesion(usuario_login, clave_login)
    if sesion:
        st.success(f"Bienvenido, {sesion['Usuario']} | Rol: {sesion['Rol']}")

        if sesion['Rol'] == 'admin':
            st.subheader("👑 Panel de administración")
            st.info("Aquí puedes gestionar usuarios, ver estadísticas globales, etc.")

            if os.path.exists(usuarios_file):
                with open(usuarios_file, mode='r', encoding='utf-8') as archivo:
                    usuarios_registrados = list(csv.DictReader(archivo))
                    for usuario in usuarios_registrados:
                        usuario["Clave"] = "••••••"

                    st.subheader("📋 Lista de usuarios registrados")
                    usuarios_df = pd.DataFrame(usuarios_registrados)
                    usuarios_df.index.name = 'ID'
                    selected_user = st.selectbox("Selecciona un usuario para eliminar o editar:", usuarios_df["Usuario"])

                    st.dataframe(usuarios_df)

                    accion = st.radio("Acción a realizar:", ["Eliminar", "Editar"])

                    if accion == "Eliminar":
                        if st.button("🗑️ Eliminar usuario"):
                            usuarios_filtrados = [u for u in usuarios_registrados if u["Usuario"] != selected_user]
                            with open(usuarios_file, mode='w', newline='', encoding='utf-8') as archivo:
                                writer = csv.DictWriter(archivo, fieldnames=["Usuario", "Correo", "Clave", "Rol"])
                                writer.writeheader()
                                writer.writerows(usuarios_filtrados)
                            st.success(f"Usuario '{selected_user}' eliminado correctamente.")
                            st.experimental_rerun()

                    elif accion == "Editar":
                        usuario_data = next((u for u in usuarios_registrados if u["Usuario"] == selected_user), None)
                        nuevo_correo = st.text_input("Nuevo correo:", value=usuario_data["Correo"])
                        nuevo_rol = st.selectbox("Nuevo rol:", ["usuario", "admin"], index=["usuario", "admin"].index(usuario_data["Rol"]))
                        nueva_clave = st.text_input("Nueva contraseña:", value="", type="password")
                        if st.button("✏️ Guardar cambios"):
                            for u in usuarios_registrados:
                                if u["Usuario"] == selected_user:
                                    u["Correo"] = nuevo_correo
                                    u["Rol"] = nuevo_rol
                                    if nueva_clave:
                                        u["Clave"] = nueva_clave
                            with open(usuarios_file, mode='w', newline='', encoding='utf-8') as archivo:
                                writer = csv.DictWriter(archivo, fieldnames=["Usuario", "Correo", "Clave", "Rol"])
                                writer.writeheader()
                                writer.writerows(usuarios_registrados)
                            st.success(f"Datos del usuario '{selected_user}' actualizados.")
                            st.experimental_rerun()
            else:
                st.warning("No hay usuarios registrados.")

        else:
            st.subheader("🎯 Panel del usuario")
            st.info("Aquí puedes registrar apuestas, ver tu historial, etc.")

    else:
        st.error("Usuario o contraseña incorrectos")
